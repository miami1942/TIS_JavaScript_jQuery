import Cookies from 'js-cookie'

console.log(Cookies.get)
