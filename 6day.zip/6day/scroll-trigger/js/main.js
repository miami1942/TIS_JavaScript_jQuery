Splitting();
gsap.registerPlugin(CSSRulePlugin);
gsap.defaults({
    ease:"back.out",
    duration:1
});
var time01 = gsap.timeline({
    scrollTrigger:{
        trigger:".section01",
        markers:true,
        start: "0 0",
        end:"100%",
        pin: true,
        pinSpacing:false,
        scrub:true,
    }
});
time01.from(".section01 .txt01 .char",{
    x:100,
    opacity:0,
    stagger:0.05
})
.from( CSSRulePlugin.getRule(".tsa .section01 .txt01:after") ,{
    cssRule:{scale:0},
    ease:"power3",
},"-=0.5")
.from(".section01 .txt02 .char",{
    x:100,
    opacity:0,
    stagger:0.05
},"-=0.8")
.from(".section01 .txt03 .txt0301",{
    x:100,
    opacity:0,
},"-=0.8")
.from(".section01 .txt03 .txt0302",{
    x:-100,
    opacity:0,
},"-=0.8")
.from(".section01 .txt03 .txt0303",{
    x:100,
    opacity:0,
},"-=0.8")
.from(".section01 .txt04",{
    scale:0,
    opacity:0,
},"-=0.8")



